package api

// MkDirs 创建各个子目录...
func MkDirs() {

}

// CpFiles 生产明细文件...
func CpFiles() {

}
